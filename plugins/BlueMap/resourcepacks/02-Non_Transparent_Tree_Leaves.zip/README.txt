upload only NTTLv1.zip to /plugins/BlueMap/resourcepacks or it wont work.
